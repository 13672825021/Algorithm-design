#include <iostream>
#include <algorithm>
#include <cstring>
#include <cstdio>
#include <set>
#include <vector>
using namespace std;
const int M=1000000;
int prime[M];//true ����  false������ 
bool composite[M];
int tot=0;
void fast_get_prime()
{	
	for(int i=2;i<M;i++)
	{
		if(composite[i]==0) prime[tot++]=i;
		for(int j=0;j<tot;j++)		
		{
			if(i%prime[j]==0)	break;
			if(i*prime[j]>=M) break;				
			composite[i*prime[j]]=true;								
		}
	}
}
int mymod(int num[],int length,int val)
{
	int ret=0;
	for(int i=0;i<length;i++)
	{
		ret=(ret*10+num[i])%val;
	}
	return ret;
}
int main()
{
	for(int i=0;i<M;i++) composite[i]=0;//all composite
	composite[0]=1;composite[1]=1;
	fast_get_prime();
	char ch[105];
	int k[105];
	int l;
	while(cin>>ch>>l&&(ch!="0"&&l!=0))
	{
		for(int i=0;i<strlen(ch);i++) k[i]=ch[i]-'0';
		bool flag=0;
		int p;
		for(int i=0;i<tot&&prime[i]<l;i++)
		{
			if(mymod(k,strlen(ch),prime[i])==0)
			{
				flag=1;
				p=prime[i];
				break;
			}
		}
		if(flag==1)
		{
			cout<<"BAD "<<p<<endl;
		}
		else cout<<"GOOD\n";
	}
} 

