#include <iostream>
#include <algorithm>
#include <cstring>
#include <cstdio>
#include <set>
#include <vector>
using namespace std;
int mymod(int x[],int val,int len)
{//valģ��  len���鳤�ȼ�����λ�� 
	int ret=0;
	for(int i=0;i<len;i++)
	{
		ret=(ret*10+x[i])%val;
	}
	return ret;
}
int main()
{
	int t;
	cin>>t;
	while(t--)
	{
		int n;
		cin>>n;
		int basis[n];
		for(int i=0;i<n;i++) cin>>basis[i];
		char ch[400];
		cin>>ch;
		int num[400];
		for(int i=0;i<strlen(ch);i++) num[i]=ch[i]-'0';
		cout<<'(';
		for(int i=0;i<n;i++)
		{
			cout<<mymod(num,basis[i],strlen(ch));
			if(i!=n-1) cout<<',';
		}
		cout<<')'<<endl;
	}
} 

