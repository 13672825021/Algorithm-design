#include <iostream>
#include <algorithm>
#include <cstring>
#include <cstdio>
#include <set>
using namespace std;
bool is_prime(int n)
{
	bool flag=1;
	for(int j=2;j*j<=n;j++)
	{
		if(n%j==0) 
		{
			flag=0; break;
		}
	}
	return flag;
}
int main()
{
	int n;
	while(cin>>n&&n!=0)
	{
		int sum=1;
		if(is_prime(n)==1) cout<<0<<endl;
		else
		{
			int sum=1;
			for(int i=n-1;i>=0;i--)
			{
				if(is_prime(i)==0) sum++;
				else break;
			}
			for(int i=n+1;i<=n+1299709;i++)
			{
				if(is_prime(i)==0) sum++;
				else break;
			}
			cout<<sum+1<<endl;
		}
		
	}
} 
// 7 8 9 10 11
//23 24 25 26 27 28 29
