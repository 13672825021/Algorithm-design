#include <iostream>
#include <algorithm>
#include <cstring>
#include <cstdio>
#include <set>
#include <vector>
#include <cmath>
using namespace std;
bool is_prime(int n)
{
	bool flag=1;
	for(int j=2;j*j<=n;j++)
	{
		if(n%j==0) 
		{
			flag=0; break;
		}
	}
	return flag;
}
int main()
{
	int n;
	cin>>n;
	long long prime[20],cnt=0;
	for(int i=2;i<n;i++)
	{
		if(is_prime(i)==1) 
		{
			prime[cnt]=i; cnt++;
		}
	}
	for(int i=0;i<cnt;i++)
	{
		bool flag=0;
		long long M_prime=pow(2,prime[i])-1;
		long long tem=M_prime;
		
		vector<long long> factor;
		for(long long j=2;j*j<=M_prime;j++)
		{
			while(M_prime%j==0)
			{
				flag=1;
				factor.push_back(j);
				M_prime/=j;
			}			
		}
		if(M_prime>1&&flag==1) factor.push_back(M_prime);
		
		if(flag==1) 
		{
			for(int j=0;j<factor.size();j++) 
			{
				cout<<factor[j];
				if(j!=factor.size()-1) cout<<" * ";
				else cout<<" = ";
			}
			cout<<tem<<" = ( 2 ^ "<<prime[i]<<" ) - 1"<<endl;
			
		}
		
	}
} 





