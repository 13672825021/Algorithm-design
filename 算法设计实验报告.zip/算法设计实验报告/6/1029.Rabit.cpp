#include <iostream>
#include <algorithm>
#include <cstring>
#include <cstdio>
#include <set>
#include <vector>
using namespace std;
struct BigInteger
{
	int num[105],len;	
	
};
BigInteger operator +(BigInteger &n1,BigInteger &n2)
{
	BigInteger ret;
	int i,g;
	for(i=g=0;i<n1.len||i<n2.len||g;i++)//����Ѿ���������������Ĵ�С�����ǽ�λg���Ǵ���0�����һ��λ 
	{
		if(i<n1.len) g+=n1.num[i];
		if(i<n2.len) g+=n2.num[i];
		ret.num[i]=g%10;
		g=g/10;
	}
	ret.len=i;
	return ret;
}
int main()
{
	int m,d;
	BigInteger f[105];
	f[0].len=1; f[0].num[0]=1;
	while(cin>>m>>d&&(m!=0||d!=0))
	{
		for(int i=1;i<=d;i++)
		{
			BigInteger sub1=f[i-1];
			BigInteger sub2;
			if(i-m<0) sub2=f[0];
			else sub2=f[i-m];
			f[i]=sub1+sub2;
		}
		for(int i=f[d].len-1;i>=0;i--)
		{
			cout<<f[d].num[i];
		}
		cout<<endl;
	}
} 

