#include <iostream>
#include <algorithm>
#include <string>
using namespace std;


int main()
{
	double w1,w2,w3,r1,r2,r3,r4;
	int count=1;
	while(cin>>w1>>r1>>w2>>r2>>w3>>r3>>r4)
	{
		cout<<"Set number "<<count<<":\n";
		count++;
		double w;
		while(cin>>w&&w!=0)
		{
			double level2=r2*(w1+1),level3=r3*(w2+1),level4=r4*(w3+1);
			if(w>=w3+1) cout<<"Weight ("<<w<<") has best price $"<<r4*w<<" (add 0 pounds)\n";
			else if(w>=w2+1) 
			{
				if(w*r3<level4) cout<<"Weight ("<<w<<") has best price $"<<r3*w<<" (add 0 pounds)\n";
				else cout<<"Weight ("<<w<<") has best price $"<<level4<<" (add "<<w3+1-w<<" pounds)\n";
			}
			else if(w>=w1+1)
			{
				double min=w*r2;
				if(level3<min) min=level3;
				if(level4<min) min=level4;
				if(min==w*r2) cout<<"Weight ("<<w<<") has best price $"<<r2*w<<" (add 0 pounds)\n";
				else if(min=level3) cout<<"Weight ("<<w<<") has best price $"<<level3<<" (add "<<w2+1-w<<" pounds)\n";
				else cout<<"Weight ("<<w<<") has best price $"<<level4<<" (add "<<w3+1-w<<" pounds)\n";
			}
			else
			{
				double min=w*r1;
				if(level2<min) min=level2;
				if(level3<min) min=level3;
				if(level4<min) min=level4;
				if(min==w*r1) cout<<"Weight ("<<w<<") has best price $"<<r1*w<<" (add 0 pounds)\n";
				else if(level2==min) cout<<"Weight ("<<w<<") has best price $"<<level2<<" (add "<<w1+1-w<<" pounds)\n";
				else if(level3==min) cout<<"Weight ("<<w<<") has best price $"<<level3<<" (add "<<w2+1-w<<" pounds)\n";
				else cout<<"Weight ("<<w<<") has best price $"<<level4<<" (add "<<w3+1-w<<" pounds)\n";
			}
		}
		cout<<endl;
	}
	
	
} 

