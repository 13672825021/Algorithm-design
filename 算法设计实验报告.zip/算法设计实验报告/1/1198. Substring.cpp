#include <iostream>
#include <algorithm>
#include <string>
using namespace std;
bool cmp(string s1,string s2)
{
	return s1+s2<s2+s1;
}
int main()
{
	int t;
	cin>>t;
	while(t--)
	{
		int n;
		cin>>n;
		string s[n];
		for(int i=0;i<n;i++) cin>>s[i];
		sort(s,s+n,cmp);
		string ss="";
		for(int i=0;i<n;i++) ss+=s[i];
		cout<<ss<<endl;
	}	
} 

