#include <iostream>
#include <algorithm>
#include <string>
using namespace std;


int main()
{
	int t,n,m,c,p,s;
	cin>>t;
	while(t--)
	{
		cin>>n>>m>>c>>p>>s;
		for(int i=1;i<=s;i++)
		{
			while((s-i+1)*c>p&&m>=p)
			{
				m-=p;
				n++;
			} 
			m+=c*n;
		}
		cout<<m<<endl;
	}
	
	
} 

