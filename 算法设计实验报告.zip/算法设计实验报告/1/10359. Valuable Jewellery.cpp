#include <iostream>
#include <algorithm>
#include <queue>
#include <vector>
using namespace std;

struct jew
{
	int m;
	int v;
};
bool cmp(jew j1,jew j2)
{
	return j1.m<j2.m;
}
struct com
{
	bool operator()(jew j1,jew j2)
	{
		return j1.v<j2.v;
	}
};
int main()
{
	priority_queue<jew,vector<jew>,com> q;
	int n,k;
	cin>>n>>k;
	vector<jew> j;
	int bag[k];
	for(int i=0;i<n;i++)
	{
		jew tem;
		cin>>tem.m>>tem.v;
		j.push_back(tem);
	}
	for(int i=0;i<k;i++) cin>>bag[i];
	sort(bag,bag+k);
	sort(j.begin(),j.end(),cmp);
	long long sum=0;
	int index=0;
	for(int i=0;i<k;i++)
	{
		while(j[index].m<=bag[i]&&index<n)
		{
			q.push(j[index]);
			index++;
		}
		if(q.empty()==0)
		{
			sum+=q.top().v;
			q.pop();
		}
	}
	cout<<sum<<endl;
	
} 

