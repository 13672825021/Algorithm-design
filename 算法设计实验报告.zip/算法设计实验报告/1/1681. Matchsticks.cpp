#include <iostream>
#include <algorithm>
#include <string>
using namespace std;


int main()
{
	int t,n;
	cin>>t;
	while(t--)
	{
		cin>>n;
		int tem=n%7;
		switch(tem)
		{
			case 0:for(int i=0;i<n/7;i++)cout<<8;break;
			case 1:cout<<10;for(int i=0;i<n/7-1;i++)cout<<8;break;
			case 2:cout<<1;for(int i=0;i<n/7;i++)cout<<8;break;
			case 3:
			if(n/7>=2) { cout<<200;for(int i=0;i<n/7-2;i++)cout<<8;}			
			else if(n/7>=1) {cout<<22;for(int i=0;i<n/7-1;i++)cout<<8;}
			else {cout<<7;} 
			break;
			case 4:
			if(n/7>=1){cout<<20;for(int i=0;i<n/7-1;i++)cout<<8;}
			else {cout<<4;	}		
			break;
			case 5:cout<<2;for(int i=0;i<n/7;i++)cout<<8;break;
			case 6:cout<<6;for(int i=0;i<n/7;i++)cout<<8; break;
			default: break;
		}
		cout<<" ";
		if(n%2==0) 
		{
			for(int i=0;i<n/2;i++) cout<<1;
		}
		else
		{
			cout<<7;
			for(int i=0;i<n/2-1;i++) cout<<1;
		}
		cout<<endl;
	}
	
	
} 

