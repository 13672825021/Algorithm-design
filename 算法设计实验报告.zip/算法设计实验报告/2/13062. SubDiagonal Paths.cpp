#include <iostream>
#include <algorithm>
#include <string>
using namespace std;


int main()
{
	int n;
	while(cin>>n&&n!=0)
	{
		n++;
		long long path[n][n];
		for(int i=0;i<n;i++)		
			for(int j=0;j<n;j++) path[i][j]=0;
					
		for(int i=0;i<n;i++)  path[i][0]=1;

		for(int j=1;j<n;j++)
		{
			for(int i=j;i<n;i++)
			{
				if(i<j) path[i][j]=0;
				else if(i==j) path[i][j]=path[i][j-1];
				else path[i][j]=path[i-1][j]+path[i][j-1];
			}			
		}
		cout<<path[n-1][n-1]<<endl;
	}
	
	
} 

