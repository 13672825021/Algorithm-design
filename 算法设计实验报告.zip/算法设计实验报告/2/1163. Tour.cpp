#include <iostream>
#include <algorithm>
#include <cmath>
#include <iomanip>
using namespace std;
struct point
{
	double x,y;	
};
double dis(point p1,point p2)
{
	return sqrt((p1.x-p2.x)*(p1.x-p2.x)+(p1.y-p2.y)*(p1.y-p2.y));
}
int main()
{
	int n;
	while(cin>>n)
	{
		point p[n];
		for(int i=0;i<n;i++)
		{
			cin>>p[i].x>>p[i].y;
		}
		double dp[n][n];
		
		dp[0][1]=dis(p[0],p[1]);
		//dp[1][0]=dp[0][1];
		for(int j=1;j<n;j++)//i<j
		{
			for(int i=0;i<j;i++)
			{
				if(i<j-1)
				{
					dp[i][j]=dp[i][j-1]+dis(p[j],p[j-1]);
				}
				else if(i==j-1)
				{
					dp[i][j]=1000000;
					for(int k=0;k<j-1;k++)
					{
						dp[i][j]=min(dp[i][j],dp[k][j-1]+dis(p[k],p[j]));
					}
				}
			}
		}
		cout<<fixed<<setprecision(2)<<dp[n-2][n-1]+dis(p[n-1],p[n-2])<<endl;
	}
} 

