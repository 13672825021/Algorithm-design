#include <iostream>
#include <algorithm>
#include <cstring>
#include <cstdio>
#include <set>
#include <vector>
#include <cstdlib>
#include <ctime>
#include <fstream>
using namespace std;
struct Boat
{
	int arrive,service,berth;
};
Boat boat[100];
int a[5000][100];
int n,m,l;
bool flag;
int test;
struct Boat_allocate
{
	int x,y;//����x������y 
};
Boat_allocate b[100];
bool boatvisit[100];
int berth[100][100];
int chromcnt;
struct Station
{
	int d_time,w_time,r_boat,f;
	Boat_allocate bb[100];
};
Station station[5000];
bool available(int x,int y,int curboat)//����x����y
{
	if(x+boat[curboat].service-1>=l||y+boat[curboat].berth-1>=n) return 0;
	for(int i=x;i<x+boat[curboat].service;i++)
	{
		for(int j=y;j<y+boat[curboat].berth;j++)
		{
			if(berth[i][j]!=-1)
			{
				return 0;
			}
		}
	}
	
	return 1;	
} 
void putboat(int xx,int yy,int curboat)
{
	for(int i=xx;i<xx+boat[curboat].service;i++)
	{
		for(int j=yy;j<yy+boat[curboat].berth;j++)
		{
			berth[i][j]=curboat;
		}
	}
	boatvisit[curboat]=1;
	b[curboat].x=xx;b[curboat].y=yy;	
}
Station operateres()
{
	Station s;
	int w1=0,w2=0,w3;//ʣ�µĴ����ȴ�ʱ�䣬���ʱ�� 
	for(int i=0;i<m;i++)	if(boatvisit[i]==0) w1++;
	s.r_boat=w1;
	for(int k=0;k<m;k++)	w2+=b[k].x-boat[k].arrive;
	s.w_time=w2;
	bool temflag=0;
	for(int k=l-1;k>=0;k--)//�����ʱ�� 
	{
		if(temflag==1) break;
		for(int z=0;z<n;z++)
		{
			if(berth[k][z]!=-1) 
			{
				w3=k+1;temflag=1;break;
			}
		}
	}	
	s.d_time=w3;
	s.f=w1*100+w2*2+w3;
	for(int k=0;k<m;k++)
	{
		s.bb[k].y=b[k].y;
		s.bb[k].x=b[k].x;
	}
	return s;
}
Station greedy(int index)
{
	memset(berth,-1,sizeof(berth));
	memset(boatvisit,0,sizeof(boatvisit));
	for(int z=0;z<m;z++) {	b[z].x=-1;b[z].y=-1;  }
	for(int z=0;z<m;z++)
	{
		int k=a[index][z];
		for(int i=0;i<l;i++)//����i����j 
		{
			for(int j=0;j<n;j++)if(berth[i][j]==-1)
			{		
				if(boat[k].arrive<=i&&boatvisit[k]==0&&available(i,j,k)==1)
				{
					boatvisit[k]=1;
					putboat(i,j,k);					
				}
			}
		}
	}	
	return operateres();
}
int offspring[100];
void exchange(int p[],int q[],int m_start,int _end)
{
	bool p2[100];
	for(int i=0;i<m;i++) p2[i]=0;
	for(int i=m_start;i<=_end;i++) 
	{
		offspring[i]=p[i];
		for(int j=0;j<m;j++)
		{
			if(q[j]==p[i])
			{
				p2[j]=1;
				break;
			}
		}
	}
		int index=0;
		for(int i=0;i<m;i++)
		{
			if(i<m_start||i>_end)
			{
				for(int j=index;j<m;j++)
				{
					if(p2[j]==0) 
					{
						offspring[i]=q[j];
						index++;
						break;
					}
					else index++;
				}
				
			}
		}
}
void genechange()
{
	int chromr1=rand()%1000,chromr2=rand()%1000;
	int swapr1=rand()%m,swapr2=rand()%m;
	if(swapr1>swapr2) swap(swapr1,swapr2);
	exchange(a[chromr1],a[chromr2],swapr1,swapr2);
	for(int i=0;i<m;i++) a[chromcnt][i]=offspring[i];
	exchange(a[chromr2],a[chromr1],swapr1,swapr2);
	for(int i=0;i<m;i++) a[chromcnt+1][i]=offspring[i];	
	chromcnt+=2;
}
bool cmp(Station s1,Station s2)
{
	return s1.f<s2.f;
}
void inherit()
{
	int evolve_time=2000;
	int fmin=1000;
	while(evolve_time--)
	{		 
		chromcnt=1000;//�����ɵ�Ⱦɫ���1000��ʼ��
		while(chromcnt<4998) genechange();//ֱ�������ܹ�2000��Ⱦɫ��Ϊֹ 		
		for(int i=1000;i<chromcnt;i++)
		{
			station[i]=greedy(i);
		}
//		for(int i=0;i<50;i++) cout<<station[i].f<<" ";
//		cout<<endl;
//		for(int i=1000;i<1050;i++) cout<<station[i].f<<" ";
//		cout<<endl;
//		system("pause");
		sort(station,station+4980,cmp);
//		int i=0;cout<<station[i].f<<" ";
		if(station[0].f<fmin)
		{
			fmin=station[0].f;
			cout<<fmin<<endl;
			ofstream fout("myfile.txt",ios::app);
			fout<<"test"<<test<<endl;
			for(int k=0;k<m;k++)
			{
				fout<<station[0].bb[k].y<<","<<station[0].bb[k].x<<";";
			}
		
			fout<<"remaining boat="<<station[0].r_boat<<" wt="<<station[0].w_time<<" dt="<<station[0].d_time<<" f="<<station[0].f;
			fout<<endl;
			fout.close();
		}
	}
}

int main()
{
	cin>>test;
	cin>>l>>n>>m;//�޶�ʱ�� ,��λ����������������	
	for(int i=0;i<m;i++)
	{
		cin>>boat[i].arrive>>boat[i].service>>boat[i].berth;
	}
	srand(time(0));
	for(int z=0;z<1000;z++)	for(int i=0;i<m;i++) a[z][i]=i;		
	for(int z=0;z<1000;z++)
	{
		for(int i=0;i<m;i++)
		{
			int tem=rand()%m;
			swap(a[z][i],a[z][tem]);
		}			
	}
	for(int i=0;i<1000;i++) station[i]=greedy(i);
	inherit();	
} 

