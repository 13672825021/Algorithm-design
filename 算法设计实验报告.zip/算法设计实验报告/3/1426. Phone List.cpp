#include <iostream>
#include <algorithm>
#include <cstring>
#include <cstdio>
using namespace std;
struct Trie
{
	Trie* next[10];
	bool exist;
};

Trie* root=new Trie;
bool Create_and_judge_Trie(string s)
{
	int len=s.length();
	Trie* p=root;
	bool flag=0;
	for(int i=0;i<len;i++)
	{		
		int id=s[i]-'0';
		if(p->exist==1)	{	flag=0; break;	}
		if(p->next[id]==NULL)
		{
			flag=1;//safe
			Trie* tem=new Trie;
			for(int j=0;j<10;j++)
			{
				tem->next[j]=NULL;	
				tem->exist=0;			
			}
			p->next[id]=tem;
		}
		
		p=p->next[id];
		if(i==len-1)	p->exist=1;
	}
	return flag;
}
int main()
{
	
	int t;
	cin>>t;
	string s[10005];
	while(t--)
	{
		int n;
		cin>>n;		
		for(int i=0;i<10;i++)
		{
			root->next[i]=NULL;
			root->exist=0;
		}
		bool flag=1;
		for(int i=0;i<n;i++) cin>>s[i];
		for(int i=0;i<n;i++)
		{		
			bool f=Create_and_judge_Trie(s[i]);
			if(f==0)
			{
				flag=0; break;
			}
		}
		if(flag==1) cout<<"YES"<<endl;
		else cout<<"NO"<<endl;
	}	
} 

