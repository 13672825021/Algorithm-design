#include <iostream>
#include <algorithm>
#include <cstring>
#include <cstdio>
using namespace std;
struct Node
{
	int data;
	Node *l;
	Node *r;	
};
void preorder(Node* p)
{
	if(p==NULL) return;
	cout<<" "<<p->data;
	preorder(p->l);
	preorder(p->r);
	return;
}
void inorder(Node* p)
{
	if(p==NULL) return;
	inorder(p->l);
	cout<<" "<<p->data;
	inorder(p->r);
	return;
}
void postorder(Node* p)
{
	if(p==NULL) return;	
	postorder(p->l);
	postorder(p->r);
	cout<<" "<<p->data;
	return;
}
int main()
{
	int n;
	int a[200005];
	bool f=0;
	while(cin>>n&&n!=0)
	{
		if(f==1) cout<<endl;
		f=1;
		Node* root=new Node;
		for(int i=0;i<n;i++) cin>>a[i];
		root->data=a[0];
		root->l=NULL;
		root->r=NULL;
		for(int i=1;i<n;i++)
		{
			Node *p=root;
			Node *tem=p;
			bool ele=0;
			while(tem!=NULL)
			{
				p=tem;
				if(a[i]<=p->data) {	tem=p->l; ele=0;}
				else {	tem=p->r; ele=1;}
			}
			if(tem==NULL)
			{
				if(ele==0)
				{
					Node* t=new Node;
					t->data=a[i];
					t->l=NULL; t->r=NULL;
					p->l=t;
				}
				else
				{
					Node* t=new Node;
					t->data=a[i];
					t->l=NULL; t->r=NULL;
					p->r=t;
				}
			}
		}
		cout<<"Inorder:";
		inorder(root);
		cout<<endl;
		cout<<"Preorder:";
		preorder(root);
		cout<<endl;
		cout<<"Postorder:";
		postorder(root);
		cout<<endl;
	}	
} 

