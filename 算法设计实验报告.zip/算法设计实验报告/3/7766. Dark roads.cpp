#include <iostream>
#include <algorithm>
#include <cstring>
#include <cstdio>
using namespace std;
struct Edge
{
	int s,e,d;
};
Edge edge[200005];
int father[200005];
bool cmp(Edge e1,Edge e2)
{
	return e1.d<e2.d;
}
int findroot(int x)
{
	if(father[x]==x) return x;
	else
	{
		father[x]=findroot(father[x]);
		return father[x];
	}
}
int main()
{
	
	int m,n,ss,ee,dd;
	while(cin>>m>>n&&m!=0&&n!=0)
	{
		int sum0=0;
		for(int i=0;i<n;i++)
		{
			cin>>ss>>ee>>dd;
			sum0+=dd;
			edge[i].s=ss;edge[i].e=ee;edge[i].d=dd;
		}
		sort(edge,edge+n,cmp);
		for(int i=0;i<m;i++) father[i]=i;
		int sum=0;
		for(int i=0;i<n;i++)
		{
			int start=edge[i].s,end=edge[i].e,dis=edge[i].d;
			int root1=findroot(start),root2=findroot(end);
			if(root1!=root2)
			{
				father[root1]=root2;
				sum+=dis;			
			}
		}
		cout<<sum0-sum<<endl;
	}

	
} 
��
