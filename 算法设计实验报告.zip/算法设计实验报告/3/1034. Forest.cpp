#include <iostream>
#include <algorithm>
#include <cstring>
#include <cstdio>
using namespace std;
const int Max=105;
bool isroot[Max];
int g[Max][Max];
bool visited[Max];
int width[Max];
int depth;
int n,m;

void dps(int index,int d)
{
	if(d>depth) depth=d;
	visited[index]=1;
	for(int i=1;i<=n;i++)
	{
		if(g[index][i]==1)
		{			
			width[d+1]++;
			//cout<<"d="<<d<<endl;
			dps(i,d+1);
			
		}
	}
}
int main()
{
	
	while(cin>>n>>m&&n!=0)
	{		
		bool flag=1;
		depth=0;		
		memset(width,0,sizeof(width));
		memset(isroot,1,sizeof(isroot));
		memset(visited,0,sizeof(visited));
		int s,e;
		for(int i=1;i<=n;i++)
			for(int j=1;j<=n;j++) g[i][j]=0;
		for(int i=0;i<m;i++)
		{
			cin>>s>>e;
			if(isroot[e]==0)  flag=0;	
			isroot[e]=0;
			g[s][e]=1;
		}
		for(int i=1;i<=n;i++)
		{
			if(isroot[i]==1)
			{
				width[0]++;
				dps(i,0);
			} 
		}
		for(int i=1;i<=n;i++)
		{
			if(visited[i]==0) 
			{
				flag=0;break;
			}
		}
		//cout<<"depth"<<depth<<endl;
		if(flag==0) cout<<"INVALID\n";
		else
		{
			int w=0;
			for(int i=0;i<=depth;i++)
			{
				//cout<<"width[i]="<<width[i]<<endl;
				if(width[i]>w) w=width[i];
			}
			cout<<depth<<" "<<w<<endl;	
		}
	}
	
} 

