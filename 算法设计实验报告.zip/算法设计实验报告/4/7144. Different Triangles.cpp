#include <iostream>
#include <algorithm>
#include <cstring>
#include <cstdio>
using namespace std;
bool vis[105];
bool Vis[105][105][105];
int n;
int a[105];
int sum;
void print()
{
	int tri[3],cnt=0,index[3];
	for(int i=0;i<n;i++)
	{
		if(vis[i]==1) 
		{
			tri[cnt]=a[i];
			index[cnt]=i;
			cnt++;
		}
	}
	if(tri[0]+tri[1]>tri[2]&&tri[0]+tri[2]>tri[1]&&tri[1]+tri[2]>tri[0])
	{
		int a=index[0],b=index[1],c=index[2];
		if(Vis[a][b][c]==0) sum++;
		Vis[a][b][c]=1;
	}
}
void dfs(int cur,int point)
{
	if(point>=3) 
	{
		print();
		return ;
	}	
	if(cur>=n) return ;	
	dfs(cur+1,point);
	vis[cur]=1;
	dfs(cur+1,point+1);
	vis[cur]=0;
	return ;
}

int main()
{
	int t;
	cin>>t;
	
	while(t--)
	{
		sum=0;
		memset(vis,0,sizeof(vis));
		memset(Vis,0,sizeof(Vis));
		cin>>n;
		for(int i=0;i<n;i++) cin>>a[i];
		dfs(0,0);
		cout<<sum<<endl;
	}
} 

