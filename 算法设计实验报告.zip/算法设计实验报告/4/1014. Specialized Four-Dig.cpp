#include <iostream>
#include <algorithm>
#include <cstring>
#include <cstdio>
using namespace std;
int Hex[4];
int Duo[4];
int Dec[4];
int dec_to_hex(int num)
{
	int sum=0;
	Hex[0]=num%16;
	num/=16;
	Hex[1]=num%16;
	num/=16;
	Hex[2]=num%16;
	num/=16;
	Hex[3]=num%16;
	for(int i=0;i<4;i++) sum+=Hex[i];
	return sum;
}
int  dec_to_duo(int num)
{
	int sum=0;
	Duo[0]=num%12;
	num/=12;
	Duo[1]=num%12;
	num/=12;
	Duo[2]=num%12;
	num/=12;
	Duo[3]=num%12;
	num/=12;
	for(int i=0;i<4;i++) sum+=Duo[i];
	return sum;
}
int countdec(int num)
{
	int sum=0;
	Dec[0]=num%10;
	num/=10;
	Dec[1]=num%10;
	num/=10;
	Dec[2]=num%10;
	num/=10;
	Dec[3]=num%10;
	num/=10;
	for(int i=0;i<4;i++) sum+=Dec[i];
	return sum;
}
int main()
{
	for(int i=1000;i<=9999;i++)
	{
		if(dec_to_hex(i)==dec_to_duo(i)&&dec_to_duo(i)==countdec(i))
			cout<<i<<endl;
	}
	//cout<<dec_to_hex(2991)<<"  "<<dec_to_duo(1991);
	//for(int i=0;i<4;i++) cout<<Hex[i]<<" ";
} 

