#include <iostream>
#include <algorithm>
#include <cstring>
#include <cstdio>
#include <queue>
using namespace std;
struct pos
{
	pos(int xx=0,int yy=0):x(xx),y(yy){}
	int x,y;	
};

int m,n;
bool vis[25][25][25][25];
//0:up 1:down 2:ledt 3:right
struct mov
{
	int x,y;
};
bool isover(pos p)
{
	if(p.x>=n||p.x<0||p.y<0||p.y>=m) return 1;
	else return 0;
}
struct state
{
	state(pos pp,pos hh)
	{
		p=pp;h=hh;step=0;
	}
	pos p,h;
	int step;
};
char ch[21][21];
mov boy[4],girl[4];
int bfs(pos pp,pos hh)
{
	vis[pp.x][pp.y][hh.x][hh.y]=1;
	queue<state> q;
	q.push(state(pp,hh));
	while(q.empty()==0)
	{				
		state cur=q.front();
		q.pop();
		if(cur.step>255) break;
		cur.step++;
		for(int i=0;i<4;i++)
		{
			
			int nextpx,nextpy,nexthx,nexthy;
			nextpx=cur.p.x+boy[i].x,nextpy=cur.p.y+boy[i].y,nexthx=cur.h.x+girl[i].x,nexthy=cur.h.y+girl[i].y;			
			if(ch[nexthx][nexthy]=='#') 
			{
				nexthx=cur.h.x;nexthy=cur.h.y;
			}
			pos nextp(nextpx,nextpy),nexth(nexthx,nexthy);
			
			if(isover(nextp)==0&&isover(nexth)==0&&vis[nextpx][nextpy][nexthx][nexthy]==0&&ch[nextpx][nextpy]=='.'&&ch[nexthx][nexthy]!='!')
			{
				vis[nextpx][nextpy][nexthx][nexthy]=1;
				if((nextpx==nexthx&&nextpy==nexthy)||(cur.p.x==nexthx&&cur.p.y==nexthy&&cur.h.x==nextpx&&cur.h.y==nextpy))
				{
					return cur.step;
				}				
				state next(nextp,nexth);
				next.step=cur.step;
				q.push(next);
			}
		}
	}
	return -1;
}

int main()
{
	memset(vis,0,sizeof(vis));
	cin>>n>>m;
	pos p,h;
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<m;j++) 
		{
			cin>>ch[i][j];
			if(ch[i][j]=='P')
			{
				p.x=i;p.y=j;
				ch[i][j]='.';
			}
			else if(ch[i][j]=='H')
			{
				h.x=i;h.y=j;
				ch[i][j]='.';
			}
		}			
	}
	mov tem1,tem2,tem3,tem4;//x�����·��� y�����ҷ��� 
	tem1.x=-1;tem1.y=0;//N
	tem2.x=1;tem2.y=0;//S
	tem3.x=0;tem3.y=-1;//W
	tem4.x=0;tem4.y=1;//E
	boy[0]=tem1;
	boy[1]=tem2;
	boy[2]=tem3;
	boy[3]=tem4;
	char chh;
	for(int i=0;i<4;i++)
	{
		cin>>chh;
		switch(chh)
		{
			case 'N': girl[i]=tem1;break;
			case 'S': girl[i]=tem2;break;
			case 'W': girl[i]=tem3;break;
			case 'E': girl[i]=tem4;break;
			default: break;
		}
	}
	int res=bfs(p,h);
	if(res==-1) cout<<"Impossible\n";
	else cout<<res<<endl;
	
} 

